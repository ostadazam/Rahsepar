import { createFileRoute } from "@tanstack/react-router";
import { RahseparApp } from "@/components/rahsepar-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RahseparApp />;
}
