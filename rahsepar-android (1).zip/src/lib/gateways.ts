export type GatewayKind = "region" | "edge" | "custom";

export type Gateway = {
  id: string;
  title: string;
  place: string;
  kind: GatewayKind;
  url: string;
};

export type ProbeResult = {
  id: string;
  attempts: number;
  samples: number[];
  median: number | null;
  jitter: number | null;
  loss: number;
  score: number | null;
};

const region = (id: string, title: string, place: string, awsRegion: string): Gateway => ({
  id,
  title,
  place,
  kind: "region",
  url: `https://s3.${awsRegion}.amazonaws.com/rahsepar-latency-probe`,
});

export const CATALOG: Gateway[] = [
  region("dxb", "دبی", "امارات", "me-central-1"),
  region("bah", "منامه", "بحرین", "me-south-1"),
  region("bom", "بمبئی", "هند", "ap-south-1"),
  region("fra", "فرانکفورت", "آلمان", "eu-central-1"),
  region("lhr", "لندن", "بریتانیا", "eu-west-2"),
  region("cdg", "پاریس", "فرانسه", "eu-west-3"),
  region("arn", "استکهلم", "سوئد", "eu-north-1"),
  region("iad", "ویرجینیا", "آمریکا", "us-east-1"),
  region("pdx", "اورگن", "آمریکا", "us-west-2"),
  region("nrt", "توکیو", "ژاپن", "ap-northeast-1"),
  region("sin", "سنگاپور", "سنگاپور", "ap-southeast-1"),
  region("syd", "سیدنی", "استرالیا", "ap-southeast-2"),
  {
    id: "cf",
    title: "کلادفلر",
    place: "نزدیک‌ترین لبه",
    kind: "edge",
    url: "https://cp.cloudflare.com/",
  },
  {
    id: "google",
    title: "گوگل",
    place: "نزدیک‌ترین لبه",
    kind: "edge",
    url: "https://www.google.com/generate_204",
  },
  {
    id: "firefox",
    title: "فایرفاکس",
    place: "نزدیک‌ترین لبه",
    kind: "edge",
    url: "https://detectportal.firefox.com/success.txt",
  },
];

export function summarize(attempts: number, samples: number[]): Omit<ProbeResult, "id"> {
  if (samples.length === 0) {
    return {
      attempts,
      samples: [],
      median: null,
      jitter: null,
      loss: attempts > 0 ? 1 : 0,
      score: null,
    };
  }
  const sorted = [...samples].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  const median =
    sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
  const jitter = sorted.length > 1 ? sorted[sorted.length - 1] - sorted[0] : 0;
  const loss = attempts > 0 ? Math.max(0, (attempts - samples.length) / attempts) : 0;
  const latency = Math.max(0, 100 - median / 4.2);
  const score = Math.max(0, Math.round(latency - Math.min(28, jitter / 6) - loss * 45));
  return { attempts, samples: [...samples], median, jitter, loss, score };
}

export function rankResults(list: ProbeResult[]): ProbeResult[] {
  return [...list].sort((a, b) => {
    if (a.score == null && b.score == null) return 0;
    if (a.score == null) return 1;
    if (b.score == null) return -1;
    if (b.score !== a.score) return b.score - a.score;
    return (a.median ?? 1e9) - (b.median ?? 1e9);
  });
}

export function qualityLabel(score: number | null, attempts = 1): string {
  if (attempts === 0) return "در انتظار";
  if (score == null) return "بی‌پاسخ";
  if (score >= 82) return "عالی";
  if (score >= 64) return "خوب";
  if (score >= 42) return "متوسط";
  return "کند";
}

export function isGateway(value: unknown): value is Gateway {
  if (!value || typeof value !== "object") return false;
  const g = value as Gateway;
  return (
    g.kind === "custom" &&
    typeof g.id === "string" &&
    typeof g.title === "string" &&
    g.title.length > 0 &&
    g.title.length < 40 &&
    typeof g.place === "string" &&
    typeof g.url === "string" &&
    g.url.startsWith("https://") &&
    g.url.length < 300
  );
}

export async function timeRequest(
  url: string,
  signal: AbortSignal,
  timeoutMs: number,
): Promise<number | null> {
  if (signal.aborted) return null;
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  signal.addEventListener("abort", onAbort);
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const t0 = performance.now();
  try {
    const sep = url.includes("?") ? "&" : "?";
    await fetch(`${url}${sep}cb=${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, {
      method: "GET",
      mode: "no-cors",
      cache: "no-store",
      redirect: "follow",
      signal: ctrl.signal,
    });
    return performance.now() - t0;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", onAbort);
  }
}

export async function mapPool<T>(
  items: T[],
  limit: number,
  fn: (item: T, index: number) => Promise<void>,
): Promise<void> {
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (cursor < items.length) {
      const index = cursor;
      cursor += 1;
      await fn(items[index], index);
    }
  });
  await Promise.all(workers);
}

export async function measureThroughput(
  signal: AbortSignal,
  bytes: number,
): Promise<number | null> {
  if (signal.aborted) return null;
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  signal.addEventListener("abort", onAbort);
  const timer = setTimeout(() => ctrl.abort(), 12000);
  try {
    const t0 = performance.now();
    const res = await fetch(
      `https://speed.cloudflare.com/__down?bytes=${bytes}&cb=${Date.now()}`,
      { cache: "no-store", signal: ctrl.signal },
    );
    if (!res.ok) return null;
    const buf = await res.arrayBuffer();
    const ms = performance.now() - t0;
    if (ms < 40 || buf.byteLength < 1000) return null;
    return (buf.byteLength * 8) / (ms / 1000) / 1_000_000;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", onAbort);
  }
}

export async function readCloudflareColo(signal: AbortSignal): Promise<string | null> {
  if (signal.aborted) return null;
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  signal.addEventListener("abort", onAbort);
  const timer = setTimeout(() => ctrl.abort(), 5000);
  try {
    const { Capacitor, CapacitorHttp } = await import("@capacitor/core");
    if (Capacitor.isNativePlatform()) {
      const r = await CapacitorHttp.get({
        url: `https://www.cloudflare.com/cdn-cgi/trace?cb=${Date.now()}`,
        connectTimeout: 5000,
        readTimeout: 5000,
      });
      return String(r.data).match(/colo=([A-Za-z0-9]+)/)?.[1] ?? null;
    }
    const res = await fetch(`https://www.cloudflare.com/cdn-cgi/trace?cb=${Date.now()}`, {
      cache: "no-store",
      signal: ctrl.signal,
    });
    if (!res.ok) return null;
    const text = await res.text();
    return text.match(/colo=([A-Za-z0-9]+)/)?.[1] ?? null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", onAbort);
  }
}
