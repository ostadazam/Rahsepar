import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Copy, Plus, Radar, Trash2, Unplug } from "lucide-react";
import {
  CATALOG,
  isGateway,
  mapPool,
  measureThroughput,
  qualityLabel,
  rankResults,
  readCloudflareColo,
  summarize,
  timeRequest,
  type Gateway,
  type ProbeResult,
} from "@/lib/gateways";

type Status = "idle" | "scanning" | "ready" | "connected";

const nf0 = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 });
const nf1 = new Intl.NumberFormat("fa-IR", {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});
const nf2 = new Intl.NumberFormat("fa-IR", { minimumIntegerDigits: 2 });

function formatMs(value: number | null, attempts = 1): string {
  if (attempts === 0) return "…";
  if (value == null) return "—";
  return nf0.format(Math.round(value));
}

function formatClock(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${nf2.format(m)}:${nf2.format(s)}`;
}

function snapshot(list: Gateway[], bag: Map<string, { attempts: number; samples: number[] }>): ProbeResult[] {
  return list.map((gateway) => {
    const row = bag.get(gateway.id) ?? { attempts: 0, samples: [] };
    return { id: gateway.id, ...summarize(row.attempts, row.samples) };
  });
}

export function RahseparApp() {
  const [custom, setCustom] = useState<Gateway[]>([]);
  const [auto, setAuto] = useState(true);
  const [hydrated, setHydrated] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [phase, setPhase] = useState("آمادهٔ جستجو");
  const [log, setLog] = useState<string[]>([]);
  const [results, setResults] = useState<ProbeResult[]>([]);
  const [done, setDone] = useState(0);
  const [total, setTotal] = useState(0);
  const [mbps, setMbps] = useState<number | null>(null);
  const [colo, setColo] = useState<string | null>(null);
  const [connectedId, setConnectedId] = useState<string | null>(null);
  const [since, setSince] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [livePing, setLivePing] = useState<number | null>(null);
  const [misses, setMisses] = useState(0);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [formError, setFormError] = useState("");
  const [copyNote, setCopyNote] = useState("");

  const gateways = useMemo(() => [...custom, ...CATALOG], [custom]);
  const gatewaysRef = useRef(gateways);
  gatewaysRef.current = gateways;
  const autoRef = useRef(auto);
  autoRef.current = auto;
  const connectedRef = useRef(connectedId);
  connectedRef.current = connectedId;

  const abortRef = useRef<AbortController | null>(null);
  const scanGen = useRef(0);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    try {
      const raw = localStorage.getItem("rahsepar-custom");
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) setCustom(parsed.filter(isGateway).slice(0, 8));
      }
      if (localStorage.getItem("rahsepar-auto") === "0") setAuto(false);
    } catch {
      /* ignore broken local prefs */
    }
    setHydrated(true);
    return () => {
      mounted.current = false;
      abortRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("rahsepar-custom", JSON.stringify(custom));
  }, [custom, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("rahsepar-auto", auto ? "1" : "0");
  }, [auto, hydrated]);

  useEffect(() => {
    if (status !== "connected" || since == null) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [status, since]);

  useEffect(() => {
    if (status !== "connected" || !connectedId) return;
    const ctrl = new AbortController();
    let stop = false;
    let busy = false;
    const id = connectedId;
    const beat = async () => {
      if (stop || busy) return;
      const gateway = gatewaysRef.current.find((item) => item.id === id);
      if (!gateway) return;
      busy = true;
      const ms = await timeRequest(gateway.url, ctrl.signal, 3500);
      busy = false;
      if (stop || !mounted.current) return;
      setLivePing(ms);
      setMisses((count) => (ms == null ? count + 1 : 0));
    };
    void beat();
    const timer = setInterval(() => void beat(), 5000);
    return () => {
      stop = true;
      ctrl.abort();
      clearInterval(timer);
    };
  }, [status, connectedId]);

  const byId = useMemo(() => new Map(gateways.map((item) => [item.id, item])), [gateways]);

  function pushLog(line: string) {
    setLog((prev) => [...prev, line].slice(-7));
  }

  function connectTo(id: string) {
    setConnectedId(id);
    setSince(Date.now());
    setNow(Date.now());
    setLivePing(null);
    setMisses(0);
    setStatus("connected");
    setPhase("متصل");
    const gateway = gatewaysRef.current.find((item) => item.id === id);
    if (gateway) pushLog(`اتصال به ${gateway.title}`);
  }

  function disconnect() {
    setConnectedId(null);
    setSince(null);
    setLivePing(null);
    setMisses(0);
    setStatus(results.length > 0 ? "ready" : "idle");
    setPhase("قطع شد");
  }

  async function runScan() {
    if (status === "scanning") {
      abortRef.current?.abort();
      return;
    }
    const gen = ++scanGen.current;
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    const list = gatewaysRef.current;
    const bag = new Map<string, { attempts: number; samples: number[] }>();
    for (const gateway of list) bag.set(gateway.id, { attempts: 0, samples: [] });

    const still = () => mounted.current && scanGen.current === gen && !ac.signal.aborted;

    try {
    setStatus("scanning");
    setConnectedId(null);
    setSince(null);
    setLivePing(null);
    setMisses(0);
    setMbps(null);
    setColo(null);
    setCopyNote("");
    setDone(0);
    setTotal(list.length);
    setLog([]);
    setResults(snapshot(list, bag));
    setPhase("سنجش تأخیر");
    pushLog(`${nf0.format(list.length)} مسیر با اینترنت تو چک می‌شود`);

    const probe = async (gateway: Gateway, timeoutMs: number) => {
      if (!still()) return;
      const row = bag.get(gateway.id);
      if (!row) return;
      row.attempts += 1;
      const ms = await timeRequest(gateway.url, ac.signal, timeoutMs);
      if (!still()) return;
      if (ms != null) row.samples.push(ms);
      setResults(snapshot(list, bag));
    };

    await mapPool(list, 5, async (gateway) => {
      await probe(gateway, 3200);
      if (!still()) return;
      setDone((count) => count + 1);
      const row = bag.get(gateway.id);
      const last = row?.samples[row.samples.length - 1];
      pushLog(last != null ? `${gateway.title} · ${formatMs(last)} ms` : `${gateway.title} · بی‌پاسخ`);
    });
    if (!still()) {
      if (mounted.current && scanGen.current === gen) {
        setStatus("ready");
        setPhase("متوقف شد");
      }
      return;
    }

    const alive = list.filter((gateway) => (bag.get(gateway.id)?.samples.length ?? 0) > 0);
    for (let round = 0; round < 2; round += 1) {
      if (!still() || alive.length === 0) break;
      setPhase(round === 0 ? "چک پایداری" : "اندازهٔ لرزش");
      await mapPool(alive, 5, async (gateway) => {
        await probe(gateway, 2500);
      });
    }
    if (!still()) {
      if (mounted.current && scanGen.current === gen) {
        setStatus("ready");
        setPhase("متوقف شد");
      }
      return;
    }

    setPhase("سنجش سرعت خط");
    pushLog("دانلود آزمایشی برای سرعت خط…");
    const warmup = await measureThroughput(ac.signal, 40_000);
    const measured = await measureThroughput(ac.signal, 280_000);
    const line = measured ?? warmup;
    const nearest = await readCloudflareColo(ac.signal);
    if (!still()) {
      if (mounted.current && scanGen.current === gen) {
        setStatus("ready");
        setPhase("متوقف شد");
      }
      return;
    }
    setMbps(line);
    setColo(nearest);
    if (line != null) pushLog(`سرعت خط حدود ${nf1.format(line)} مگابیت`);
    else pushLog("سرعت دانلود از این شبکه خوانده نشد");
    if (nearest) pushLog(`لبهٔ کلادفلر: ${nearest}`);

    const ranked = rankResults(snapshot(list, bag));
    setResults(ranked);
    const connectable = new Set(
      list.filter((gateway) => gateway.kind !== "edge").map((gateway) => gateway.id),
    );
    const winner = ranked.find((row) => row.score != null && connectable.has(row.id));
    if (!winner) {
      setStatus("ready");
      setPhase("مسیر قابل اتصال پیدا نشد");
      pushLog("مناطق جواب ندادند. یک آدرس خودت اضافه کن یا دوباره بسنج.");
      return;
    }
    const gateway = list.find((item) => item.id === winner.id);
    pushLog(`سریع‌ترین پایدار: ${gateway?.title ?? "—"}`);
    if (autoRef.current) connectTo(winner.id);
    else {
      setStatus("ready");
      setPhase("آمادهٔ اتصال");
    }
    } catch {
      if (mounted.current && scanGen.current === gen) {
        setStatus("ready");
        setPhase("سنجش ناتمام ماند");
      }
    }
  }

  function addCustom(event: FormEvent) {
    event.preventDefault();
    const title = name.trim();
    const nextUrl = url.trim();
    if (title.length < 2) {
      setFormError("یک نام کوتاه بده.");
      return;
    }
    if (!nextUrl.startsWith("https://")) {
      setFormError("فقط آدرس https پذیرفته می‌شود.");
      return;
    }
    if (custom.length >= 8) {
      setFormError("بیشتر از ۸ مسیر شخصی جا نیست.");
      return;
    }
    const gateway: Gateway = {
      id: `custom-${crypto.randomUUID()}`,
      title,
      place: "مسیر خودت",
      kind: "custom",
      url: nextUrl,
    };
    setCustom((prev) => [gateway, ...prev]);
    setName("");
    setUrl("");
    setFormError("");
  }

  const connected = connectedId ? byId.get(connectedId) : undefined;
  const regionRows = results.filter((row) => byId.get(row.id)?.kind !== "edge");
  const edgeRows = results.filter((row) => byId.get(row.id)?.kind === "edge");
  const liveLabel =
    status === "connected" && connected
      ? connected.title
      : status === "scanning"
        ? "در حال جستجو"
        : "آماده";
  const liveValue =
    status === "connected"
      ? formatMs(livePing)
      : status === "scanning" && total > 0
        ? `${nf0.format(Math.min(done, total))}/${nf0.format(total)}`
        : "—";
  const linkHealth = misses >= 2 ? "افت مسیر" : misses === 1 ? "یک چک ناموفق" : "پایدار";

  async function copyPick() {
    if (!connected) return;
    const row = results.find((item) => item.id === connected.id);
    const text = `بهترین مسیر از اینترنت من: ${connected.title} (${connected.place}) با تأخیر ${formatMs(row?.median ?? null)} میلی‌ثانیه. این منطقه را در برنامهٔ VPN انتخاب کن.`;
    try {
      await navigator.clipboard.writeText(text);
      setCopyNote("پیشنهاد کپی شد");
    } catch {
      setCopyNote(text);
    }
  }

  return (
    <main className="mx-auto min-h-dvh max-w-5xl px-4 py-6 lg:px-8">
      <header className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-lg bg-primary text-primary-fg">
            <Radar className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h1 className="text-xl font-semibold">رهسپار</h1>
            <p className="text-sm text-muted">جستجو، چک، اتصال — با نت خودت</p>
          </div>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={auto}
          onClick={() => setAuto((value) => !value)}
          className="flex items-center gap-2 text-sm text-muted"
        >
          <span
            className={
              auto
                ? "relative h-6 w-11 rounded-full bg-primary"
                : "relative h-6 w-11 rounded-full border border-line bg-surface-2"
            }
          >
            <span
              className={
                auto
                  ? "absolute top-0.5 size-5 rounded-full bg-primary-fg"
                  : "absolute top-0.5 size-5 rounded-full bg-muted"
              }
              style={{ insetInlineStart: auto ? "1.2rem" : "0.125rem" }}
            />
          </span>
          خودکار
        </button>
      </header>

      <div className="mt-6 grid items-start gap-4 lg:grid-cols-3">
      <div className="grid gap-4">
      <section className="rounded-xl border border-line bg-surface px-4 py-5">
        <div className={status === "scanning" || status === "connected" ? "radar is-live" : "radar"}>
          <div className="radar-sweep" />
          <div className="radar-core">
            <div className="radar-readout">
              <p className="text-2xl font-semibold tabular-nums">{liveValue}</p>
              <p className="text-sm text-muted">{status === "connected" ? "ms زنده" : "وضعیت"}</p>
            </div>
          </div>
        </div>
        <p className="mt-4 text-center text-lg font-semibold">{liveLabel}</p>
        <p className="mt-1 text-center text-sm text-muted">{phase}</p>
        <button
          type="button"
          onClick={() => void runScan()}
          className="mt-4 h-12 w-full rounded-lg bg-primary text-base font-semibold text-primary-fg"
        >
          {status === "scanning"
            ? "توقف"
            : status === "idle"
              ? auto
                ? "جستجو، چک، اتصال"
                : "جستجو و چک"
              : "جستجوی دوباره"}
        </button>
        {status === "scanning" && total > 0 ? (
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full bg-primary"
              style={{ width: `${Math.round((Math.min(done, total) / total) * 100)}%` }}
            />
          </div>
        ) : null}
        {log.length > 0 ? (
          <ul className="mt-4 space-y-1 text-sm text-muted">
            {log.map((line, index) => (
              <li key={`${line}-${index}`} className="tabular-nums">
                {line}
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-4 text-sm text-muted">
            دوازده منطقه به اضافهٔ لبه‌های نزدیک سنجیده می‌شود. اتصال خودکار، سریع‌ترین مسیر پایدار را قفل
            می‌کند.
          </p>
        )}
      </section>

      {status === "connected" && connected ? (
        <section className="rounded-xl border border-primary bg-surface p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm text-primary">متصل</p>
              <h2 className="text-lg font-semibold">
                {connected.title}
                <span className="text-sm font-normal text-muted"> · {connected.place}</span>
              </h2>
              <p className="mt-1 text-sm text-muted">
                {linkHealth}
                {since != null ? <span className="tabular-nums"> · {formatClock(now - since)}</span> : null}
              </p>
            </div>
            <p className="text-2xl font-semibold tabular-nums text-primary">{formatMs(livePing)}</p>
          </div>
          <p className="mt-3 text-sm">
            در برنامهٔ VPN منطقهٔ «
            {connected.place === "مسیر خودت" ? connected.title : `${connected.place}، ${connected.title}`}
            » را انتخاب کن. این نشست همان مسیر را هر چند ثانیه دوباره چک می‌کند.
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={disconnect}
              className="flex h-11 items-center justify-center gap-2 rounded-lg border border-line bg-surface-2 text-sm font-medium"
            >
              <Unplug className="size-4" aria-hidden="true" />
              قطع
            </button>
            <button
              type="button"
              onClick={() => void copyPick()}
              className="flex h-11 items-center justify-center gap-2 rounded-lg border border-line bg-surface-2 text-sm font-medium"
            >
              <Copy className="size-4" aria-hidden="true" />
              کپی پیشنهاد
            </button>
          </div>
          {copyNote ? <p className="mt-2 text-sm text-muted">{copyNote}</p> : null}
        </section>
      ) : null}
      </div>

      <div className="grid content-start gap-4 lg:col-span-2">
      <section className="rounded-xl border border-line bg-surface p-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-semibold">سرعت خط</h2>
            <p className="text-sm text-muted">
              {colo ? `نزدیک‌ترین کلادفلر: ${colo}` : "بعد از جستجو با دانلود واقعی سنجیده می‌شود"}
            </p>
          </div>
          <p className="text-2xl font-semibold tabular-nums">
            {mbps == null ? "—" : nf1.format(mbps)}
            <span className="ms-1 text-sm font-normal text-muted">Mb/s</span>
          </p>
        </div>
        {edgeRows.length > 0 ? (
          <ul className="mt-3 grid grid-cols-3 gap-2">
            {edgeRows.map((row) => {
              const gateway = byId.get(row.id);
              return (
                <li key={row.id} className="rounded-lg bg-surface-2 px-2 py-2 text-center">
                  <p className="text-sm text-muted">{gateway?.title}</p>
                  <p className="font-semibold tabular-nums">{formatMs(row.median, row.attempts)}</p>
                </li>
              );
            })}
          </ul>
        ) : null}
      </section>

      <section>
        <h2 className="font-semibold">مناطق</h2>
        <p className="mt-1 text-sm text-muted">برای انتخاب داخل VPN، نه تونل کل دستگاه.</p>
        {regionRows.length === 0 ? (
          <ul className="mt-3 flex flex-wrap gap-2">
            {gateways
              .filter((gateway) => gateway.kind !== "edge")
              .map((gateway) => (
                <li key={gateway.id} className="rounded-full border border-line px-3 py-1 text-sm text-muted">
                  {gateway.title}
                </li>
              ))}
          </ul>
        ) : (
          <ul className="mt-3 grid gap-3 lg:grid-cols-2">
            {regionRows.map((row) => {
              const gateway = byId.get(row.id);
              if (!gateway) return null;
              const active = connectedId === row.id;
              return (
                <li
                  key={row.id}
                  className={
                    active
                      ? "rounded-xl border border-primary bg-surface p-4"
                      : "rounded-xl border border-line bg-surface p-4"
                  }
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-semibold">{gateway.title}</h3>
                      <p className="text-sm text-muted">{gateway.place}</p>
                    </div>
                    <p
                      className={
                        row.attempts === 0
                          ? "text-sm text-muted"
                          : row.score == null
                            ? "text-sm text-danger"
                            : "text-sm font-medium text-primary"
                      }
                    >
                      {qualityLabel(row.score, row.attempts)}
                    </p>
                  </div>
                  <dl className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm tabular-nums">
                    <div>
                      <dt className="inline text-muted">تأخیر </dt>
                      <dd className="inline">{formatMs(row.median, row.attempts)}</dd>
                    </div>
                    <div>
                      <dt className="inline text-muted">لرزش </dt>
                      <dd className="inline">{formatMs(row.jitter, row.attempts)}</dd>
                    </div>
                    <div>
                      <dt className="inline text-muted">امتیاز </dt>
                      <dd className="inline">{row.score == null ? "—" : nf0.format(row.score)}</dd>
                    </div>
                  </dl>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-2">
                    <div className="h-full bg-primary" style={{ width: `${row.score ?? 0}%` }} />
                  </div>
                  <div className="mt-3 flex gap-2">
                    {active ? (
                      <p className="flex h-11 flex-1 items-center text-sm text-primary">این مسیر قفل است</p>
                    ) : (
                      <button
                        type="button"
                        disabled={status === "scanning" || row.score == null}
                        onClick={() => connectTo(row.id)}
                        className="h-11 flex-1 rounded-lg border border-line bg-surface-2 text-sm font-medium disabled:opacity-40"
                      >
                        اتصال به این مسیر
                      </button>
                    )}
                    {gateway.kind === "custom" ? (
                      <button
                        type="button"
                        aria-label={`حذف ${gateway.title}`}
                        onClick={() => {
                          if (connectedId === gateway.id) disconnect();
                          setCustom((prev) => prev.filter((item) => item.id !== gateway.id));
                          setResults((prev) => prev.filter((item) => item.id !== gateway.id));
                        }}
                        className="flex size-11 items-center justify-center rounded-lg border border-line text-danger"
                      >
                        <Trash2 className="size-4" aria-hidden="true" />
                      </button>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <details className="rounded-xl border border-line bg-surface px-4">
        <summary className="clean-summary flex h-12 items-center justify-between font-medium">
          افزودن مسیر خودت
          <Plus className="size-4 text-muted" aria-hidden="true" />
        </summary>
        <form onSubmit={addCustom} className="grid gap-2 pb-4">
          <label htmlFor="route-name" className="text-sm text-muted">
            نام
          </label>
          <input
            id="route-name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={32}
            className="h-11 rounded-lg border border-line bg-bg px-3 text-fg"
            placeholder="مثلاً سرور هلند"
          />
          <label htmlFor="route-url" className="text-sm text-muted">
            آدرس https برای تست
          </label>
          <input
            id="route-url"
            value={url}
            dir="ltr"
            inputMode="url"
            onChange={(event) => setUrl(event.target.value)}
            className="h-11 rounded-lg border border-line bg-bg px-3 text-left text-fg"
            placeholder="https://"
          />
          {formError ? <p className="text-sm text-danger">{formError}</p> : null}
          <button
            type="submit"
            className="h-11 rounded-lg border border-line bg-surface-2 text-sm font-medium"
          >
            افزودن به جستجو
          </button>
        </form>
      </details>

      <p className="pb-6 text-sm text-muted">
        مرورگر نمی‌تواند تونل سراسری WireGuard یا OpenVPN بسازد. رهسپار با اینترنت خودت مناطق را واقعاً پینگ
        می‌کند، سرعت خط را می‌سنجد و بهترین مسیر را زنده نگه می‌دارد تا همان منطقه را در اپ VPN انتخاب کنی.
      </p>
      </div>
      </div>
    </main>
  );
}
