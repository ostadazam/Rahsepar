#!/usr/bin/env node
/**
 * Static (SPA) build for the Capacitor Android app → dist/client.
 * Usage: npm run build:android
 */
import { spawnSync } from "node:child_process";
import { copyFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";

const env = { ...process.env, CAPACITOR: "1", VITE_AUTH_ENABLED: "false", VITE_CAPACITOR: "1" };
const r = spawnSync("node", ["scripts/with-app-env.mjs", "vite", "build"], {
  stdio: "inherit",
  env,
});
if (r.status !== 0) process.exit(r.status ?? 1);

const out = join("dist", "client");
const index = join(out, "index.html");
if (!existsSync(index)) {
  // Some TanStack Start versions name the SPA shell differently.
  const shell = ["_shell.html", "shell.html"].find((f) => existsSync(join(out, f)));
  if (shell) copyFileSync(join(out, shell), index);
}
if (!existsSync(index)) {
  console.error("\n✗ dist/client/index.html not found. Files in dist/client:");
  console.error(existsSync(out) ? readdirSync(out).join("\n") : "(folder missing)");
  process.exit(1);
}
console.log("\n✓ Static build ready: dist/client/index.html");
