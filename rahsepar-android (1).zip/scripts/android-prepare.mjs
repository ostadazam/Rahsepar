#!/usr/bin/env node
/** Run after `npx cap add android`: edge-to-edge opt-out + stable signing key. */
import { readFileSync, writeFileSync } from "node:fs";

const stylesFile = "android/app/src/main/res/values/styles.xml";
let st = readFileSync(stylesFile, "utf8");
if (!st.includes("windowOptOutEdgeToEdgeEnforcement")) {
  st = st.replace(
    /(<style name="AppTheme[^"]*"[^>]*>)/g,
    '$1\n        <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>',
  );
  writeFileSync(stylesFile, st);
}

const gradleFile = "android/app/build.gradle";
let gr = readFileSync(gradleFile, "utf8");
if (!gr.includes("signingConfigs.stable")) {
  gr = gr.replace(
    "buildTypes {",
    `signingConfigs {
        stable {
            storeFile file('../../scripts/release.keystore')
            storePassword 'mizan-stable-key'
            keyAlias 'key0'
            keyPassword 'mizan-stable-key'
        }
    }
    buildTypes {
        debug { signingConfig signingConfigs.stable }`,
  );
  writeFileSync(gradleFile, gr);
}
console.log("✓ Android prepared");
